function inserCodeForm(){
  
}

function configApp(){
  
}


function allForms(){

}

function viewForm(){
  
}

function removeForm(){
  
}

function removeForm(){
  
}